import react from 'react'
import{view, text, image} from 'react-native';

const App=() =>{
  return(
    <view>
    <view>
    <text>Produto 1</text>
    <Image
        Style={{width: 200, height: 200}} 
        Source={{ uri:https://d2r9epyceweg5n.cloudfront.net/stores/992/567/products/8487021d-7efe-461e-8a33-134a6e11c4361-9dcd08cdfd8064f0c716636177911617-1024-1024.jpeg}}/>
  
    </view>
    <view>
    <text>Produto 2</text>
    </view>
    <text>Produto 3</text>
    </view>
    <view>
    <text>Produto 4</text>
    </view>
    </view>

  );
}
rxport default App:
{view=
<Text>Entre muitas vantagens, elas relaxam, proporcionam um ambiente acolhedor, dão sensação de tranquilidade... Além de que, quando acesas, a meia luz ainda promove um ambiente romântico para aquele jantar especial. E quando apagadas, é um ótimo objeto decorativo!
<image>
  Style= 
  Source=
  /