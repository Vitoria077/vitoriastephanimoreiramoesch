import React from 'react'
import{View, Text, Image} from 'react-native';

const App = () =>{
  return(
    <View>
    <View>
    <Text>Produto 1</Text>
    <Image
        style={{width: 200, height: 200}} 
        source={{ uri:'https://cdn.awsli.com.br/300x300/2450/2450278/produto/194364394/vela-bamboo-0273920610.jpg'}}
        /> 
    </View>
    <View>
    <Text>Produto 1</Text>
    <Image
        style={{width: 200, height: 200}} 
        source={{ uri:'https://cdn.awsli.com.br/300x300/2450/2450278/produto/194364394/vela-bamboo-0273920610.jpg'}}
        /> 
    </View>
    <View>
    <Text>Produto 1</Text>
    <Image
        style={{width: 200, height: 200}} 
        source={{ uri:'https://cdn.awsli.com.br/300x300/2450/2450278/produto/194364394/vela-bamboo-0273920610.jpg'}}
        /> 
    </View>
</View>    
  );
}
export default App;
